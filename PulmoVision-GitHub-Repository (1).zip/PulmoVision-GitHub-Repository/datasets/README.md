# Dataset files

- `demo_cases.json` — case records in the JSON format accepted by PulmoVision.
- `demo_cases.csv` — the same records in CSV format for spreadsheet workflows.

These are **illustrative demo cases for testing the interface and file-import workflow**. They are not sourced from patient records, a clinical study, or a validated medical dataset, and must not be used to train, validate, or claim clinical performance of a model.

## Fields

| Field | Meaning | Expected form |
|---|---|---|
| `name` | Display label | Text |
| `lobe` | Lung lobe | `RUL`, `RML`, `RLL`, `LUL`, or `LLL` |
| `diameter_mm` | Illustrative lesion diameter | Number in millimetres |
| `hu` | Illustrative mean attenuation | Number in Hounsfield units |
| `spiculation` | Demo feature input | Number from 0 to 1 |
| `fev1_percent` | Illustrative FEV1 percent | Number |
| `position` | Optional 3D placement hint | JSON array of three numbers |

Do not include identifiable patient information in uploaded files. If adding real clinical data, confirm the dataset licence, permissions, de-identification, and applicable institutional requirements first.
