# PulmoVision

**PulmoVision** is a browser-based thoracic visualization and lung-lesion simulation interface. The project provides a 3D lung scene, case-file import, configurable visualization layers, a virtual bronchoscopy-style navigator, lesion measurements, and an illustrative growth/intervention simulator.

> **Research/demo software — not a medical device.** PulmoVision is not validated for diagnosis, screening, prognosis, treatment selection, or patient care. Its heuristic scores, growth parameters, and intervention projections are illustrative and should not be interpreted as clinical evidence or recommendations.

## Features

- Interactive 3D lung visualization powered by Three.js.
- Import a case from JSON or CSV.
- Download a case template and export the current report as JSON.
- Toggle anatomical and visualization layers.
- Adjust breathing animation, opacity, lesion appearance, and navigation depth.
- Explore an illustrative Gompertz-style growth curve and intervention scenarios.
- Responsive layout for desktop and smaller screens.

## Quick start

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. For best results, run a local static server from the repository directory:

   ```bash
   python -m http.server 8000
   ```

4. Visit `http://localhost:8000`.

The page loads Three.js from a CDN, so an internet connection is required for that dependency unless you modify the project to bundle it locally.

## Load a case

Use **Drop a case file** in the Patient data section. The application accepts `.json` and `.csv` files. Example records are in [`datasets/`](datasets/).

Required case fields:
- `lobe`: `RUL`, `RML`, `RLL`, `LUL`, or `LLL`
- `diameter_mm`: lesion diameter in millimetres
- `hu`: attenuation input
- `spiculation`: demo feature from 0 to 1
- `fev1_percent`: FEV1 percent input

Optional fields include `name`/`id` and `position`. Use **Download template** in the app for a minimal JSON example.

## Repository layout

```text
PulmoVision-GitHub-Repository/
├── index.html
├── README.md
├── LICENSE
├── .gitignore
├── datasets/
│   ├── README.md
│   ├── demo_cases.csv
│   └── demo_cases.json
└── docs/
    └── LIMITATIONS.md
```

## Important limitations

- The malignancy estimate is a hand-coded heuristic, not a trained or clinically validated prediction model.
- Growth curves and treatment scenarios are illustrative simulations; they are not individualized forecasts.
- Anatomical geometry is a visualization, not a patient-specific reconstruction from CT or MRI.
- Displayed measurements and categories should not be used to make medical decisions.
- The included demo cases are for checking application behavior only, not for scientific validation.
- No server-side storage or clinical-data security workflow is provided. Avoid uploading identifiable health information.

## Dependencies

- [Three.js r128](https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js), loaded from a CDN.
- Google Fonts (Inter and JetBrains Mono), loaded from Google Fonts.

The application is primarily a standalone HTML/CSS/JavaScript project.

## Contributing

1. Fork the repository.
2. Create a feature branch.
3. Keep changes focused and document any new inputs or outputs.
4. Test case import, visualization controls, and report export in a modern browser.
5. Open a pull request describing the change and how it was tested.

## License

See [`LICENSE`](LICENSE). The license covers this repository's project files; third-party dependencies remain subject to their own licences. Confirm rights to any added datasets, images, or external code before redistributing them.
