# Scope and limitations

PulmoVision is an interactive visualization prototype. It does not perform medical image segmentation or infer anatomy from an uploaded scan. The displayed lung scene is application geometry, and case-file fields are used as inputs to a rule-based demonstration.

## Interpretation cautions

- A heuristic score is not a probability calibrated on clinical cohorts.
- The simulated growth curve is not a validated natural-history model.
- Treatment curves do not estimate real treatment efficacy.
- Suggested options are rule-based demonstrations, not clinical recommendations.
- No external validation, prospective evaluation, regulatory review, or clinical usability assessment is represented by this repository.

## Responsible extension

For research use, document data provenance and licence, define a prespecified evaluation protocol, use appropriate patient-level splits, assess calibration and subgroup performance, and obtain qualified clinical/statistical review. Do not upload identifiable patient data to this static browser application.
