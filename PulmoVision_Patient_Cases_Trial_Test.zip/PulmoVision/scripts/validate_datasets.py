#!/usr/bin/env python3
"""Validate PulmoVision CSV/JSON demo datasets and split integrity."""
from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "datasets"
REQUIRED = {"id", "lobe", "diameter_mm", "hu", "spiculation", "fev1_percent"}
LOBES = {"RUL", "RML", "RLL", "LUL", "LLL"}
MIN_ROWS = 1000


def load_pair(split: str) -> list[dict]:
    csv_path = DATA / f"patient_cases_{split}.csv"
    json_path = DATA / f"patient_cases_{split}.json"
    with csv_path.open(newline="", encoding="utf-8") as handle:
        csv_rows = list(csv.DictReader(handle))
    json_rows = json.loads(json_path.read_text(encoding="utf-8"))
    if not isinstance(json_rows, list):
        raise ValueError(f"{json_path.name}: top-level JSON value must be an array")
    if len(csv_rows) < MIN_ROWS or len(json_rows) < MIN_ROWS:
        raise ValueError(f"{split}: both formats must contain at least {MIN_ROWS} records")
    if not csv_rows or set(csv_rows[0]) != REQUIRED:
        raise ValueError(f"{split}: CSV headers do not match required schema")
    if any(set(row) != REQUIRED for row in json_rows):
        raise ValueError(f"{split}: JSON fields do not match required schema")

    normalized_csv = []
    for row in csv_rows:
        normalized_csv.append({
            "id": row["id"],
            "lobe": row["lobe"],
            "diameter_mm": float(row["diameter_mm"]),
            "hu": int(row["hu"]),
            "spiculation": float(row["spiculation"]),
            "fev1_percent": float(row["fev1_percent"]),
        })
    if normalized_csv != json_rows:
        raise ValueError(f"{split}: CSV and JSON records differ or are in a different order")

    ids = [row["id"] for row in json_rows]
    if any(not value for value in ids) or len(ids) != len(set(ids)):
        raise ValueError(f"{split}: blank or duplicate case identifiers")
    for row in json_rows:
        if row["lobe"] not in LOBES:
            raise ValueError(f"{split}: invalid lobe for {row['id']}")
        numeric = ("diameter_mm", "hu", "spiculation", "fev1_percent")
        if any(isinstance(row[key], bool) or not isinstance(row[key], (int, float))
               or not math.isfinite(row[key]) for key in numeric):
            raise ValueError(f"{split}: non-numeric or non-finite value for {row['id']}")
        if not 4 <= row["diameter_mm"] <= 70:
            raise ValueError(f"{split}: diameter outside 4-70 mm for {row['id']}")
        if not -1000 <= row["hu"] <= 300:
            raise ValueError(f"{split}: HU outside documented -1000 to 300 range for {row['id']}")
        if not 0 <= row["spiculation"] <= 1:
            raise ValueError(f"{split}: spiculation outside 0-1 for {row['id']}")
        if not 0 <= row["fev1_percent"] <= 200:
            raise ValueError(f"{split}: FEV1 percent outside 0-200 for {row['id']}")
    return json_rows


def main() -> int:
    try:
        trial = load_pair("trial")
        test = load_pair("test")
        overlap = {row["id"] for row in trial} & {row["id"] for row in test}
        if overlap:
            raise ValueError(f"trial/test case IDs overlap: {sorted(overlap)[:5]}")
        print("PASS: CSV and JSON parse successfully.")
        print(f"PASS: trial pair contains {len(trial)} matching records.")
        print(f"PASS: test pair contains {len(test)} matching records.")
        print("PASS: required fields, types, ranges, and lobe values are valid.")
        print("PASS: identifiers are unique and trial/test IDs do not overlap.")
        print("PASS: CSV/JSON records match record-for-record.")
        return 0
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
