#!/usr/bin/env python3
"""Generate reproducible PulmoVision application-testing datasets.

The records are synthetic demonstration fixtures, not patient observations.
The fixed seed and deterministic field-generation procedure make outputs
repeatable. Only fields accepted by the current PulmoVision importer are used.
"""
from __future__ import annotations

import csv
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "datasets"
SEED = 20261026
ROWS_PER_SPLIT = 1200
FIELDS = ["id", "lobe", "diameter_mm", "hu", "spiculation", "fev1_percent"]
LOBES = ["RUL", "RML", "RLL", "LUL", "LLL"]


def build_records(split: str, count: int, rng: random.Random) -> list[dict]:
    """Return deterministic, internally consistent synthetic test records."""
    records = []
    for index in range(1, count + 1):
        # Independent ID namespace prevents overlap between dataset splits.
        case_id = f"PV-{split.upper()}-{index:04d}"
        lobe = rng.choice(LOBES)
        diameter = round(rng.uniform(4.0, 70.0), 1)
        hu = rng.randint(-850, 120)
        spiculation = round(rng.uniform(0.0, 1.0), 2)
        fev1 = round(rng.uniform(35.0, 130.0), 1)
        records.append({
            "id": case_id,
            "lobe": lobe,
            "diameter_mm": diameter,
            "hu": hu,
            "spiculation": spiculation,
            "fev1_percent": fev1,
        })
    return records


def write_split(split: str, records: list[dict]) -> None:
    csv_path = OUT / f"patient_cases_{split}.csv"
    json_path = OUT / f"patient_cases_{split}.json"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="raise")
        writer.writeheader()
        writer.writerows(records)
    json_path.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rng = random.Random(SEED)
    for split in ("trial", "test"):
        write_split(split, build_records(split, ROWS_PER_SPLIT, rng))
    print(f"Generated {ROWS_PER_SPLIT} trial and {ROWS_PER_SPLIT} test records.")
    print(f"Seed: {SEED}")


if __name__ == "__main__":
    main()
